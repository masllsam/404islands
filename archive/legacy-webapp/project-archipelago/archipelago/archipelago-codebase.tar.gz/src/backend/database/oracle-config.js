//=============================================
// ARCHIPELAGO ORACLE AUTONOMOUS JSON DATABASE CONFIGURATION
//=============================================
// Production-ready configuration for Oracle Autonomous JSON Database
// Optimized for high availability and performance

const oracledb = require('oracledb');
const fs = require('fs');
const path = require('path');

// Environment variables with fallbacks
const ORACLE_CONFIG = {
  user: process.env.ORACLE_USER || 'admin',
  password: process.env.ORACLE_PASSWORD,
  connectionString: process.env.ORACLE_CONNECTION_STRING,
  walletPath: process.env.ORACLE_WALLET_PATH,

  // Connection pool settings for scalability
  poolMin: parseInt(process.env.ORACLE_POOL_MIN) || 2,
  poolMax: parseInt(process.env.ORACLE_POOL_MAX) || 20,
  poolIncrement: parseInt(process.env.ORACLE_POOL_INCREMENT) || 2,

  // Connection timeouts
  connectTimeout: parseInt(process.env.ORACLE_CONNECT_TIMEOUT) || 15, // seconds
  reconnectTries: parseInt(process.env.ORACLE_RECONNECT_TRIES) || 3,

  // SSL/TLS configuration for secure connections
  ssl: {
    trustServerCertificate: true,
    ssl: true,
    rejectUnauthorized: false,
    // Wallet location for encrypted connections
    walletLocation: process.env.ORACLE_WALLET_PATH,
    walletPassword: process.env.ORACLE_WALLET_PASSWORD
  },

  // Enable Oracle JSON features
  jsonDocumentFormat: 'OSON', // Optimized JSON format
  fetchAsString: [oracledb.CLOB],
  fetchAsBuffer: [oracledb.BLOB],

  // Performance optimization
  prefetchRows: 100,
  fetchArraySize: 100,

  // Enable external authentication if password not provided
  externalAuth: !process.env.ORACLE_PASSWORD
};

//=============================================
// CONNECTION STRING EXAMPLES
//=============================================
/*
For Oracle Autonomous JSON Database:

// Development (with wallet):
ORACLE_CONNECTION_STRING="(DESCRIPTION=(RETRY_COUNT=20)(RETRY_DELAY=3)(ADDRESS=(PROTOCOL=TCPS)(PORT=1521)(HOST=adb.region.oraclecloud.com))(CONNECT_DATA=(SERVICE_NAME=adb_databaseid_low.adb.oraclecloud.com))(SECURITY=(MY_WALLET_DIRECTORY=/path/to/wallet)))"

// Development (basic):
ORACLE_CONNECTION_STRING="adb.region.oraclecloud.com:1521/adb_databaseid_low.adb.oraclecloud.com"

// Production example:
ORACLE_CONNECTION_STRING="adb-prod.region.oraclecloud.com:1521/databaseid.adb.oraclecloud.com"

Environment Variables Required:
- ORACLE_USER: Database username
- ORACLE_PASSWORD: Database password (optional with wallet auth)
- ORACLE_CONNECTION_STRING: Full connection string
- ORACLE_WALLET_PATH: Path to Oracle wallet directory (optional)
- ORACLE_WALLET_PASSWORD: Wallet password (optional)
*/

//=============================================
// DATABASE CONNECTION MANAGER
//=============================================
class OracleConnectionManager {
  constructor() {
    this.pool = null;
    this.isInitialized = false;
    this.connectionRetries = 0;
    this.maxRetries = ORACLE_CONFIG.reconnectTries;
  }

  async initialize(initConfig = {}) {
    try {
      // Override default config if provided
      const config = { ...ORACLE_CONFIG, ...initConfig };

      // Validate required configuration
      if (!config.connectionString) {
        throw new Error('Oracle connection string is required. Set ORACLE_CONNECTION_STRING environment variable.');
      }

      if (!config.externalAuth && !config.password) {
        throw new Error('Oracle password is required. Set ORACLE_PASSWORD environment variable or enable external auth.');
      }

      // Configure wallet if provided
      if (config.walletPath) {
        if (!fs.existsSync(config.walletPath)) {
          throw new Error(`Oracle wallet path does not exist: ${config.walletPath}`);
        }
        oracledb.initOracleClient({ libDir: config.walletPath });
        console.log('🔐 Oracle wallet configured successfully');
      }

      // Create connection pool
      this.pool = await oracledb.createPool({
        user: config.user,
        password: config.password,
        connectionString: config.connectionString,
        poolMin: config.poolMin,
        poolMax: config.poolMax,
        poolIncrement: config.poolIncrement,
        connectTimeout: config.connectTimeout * 1000, // Convert to milliseconds
        jsonDocumentFormat: config.jsonDocumentFormat,
        prefetchRows: config.prefetchRows,
        fetchArraySize: config.fetchArraySize,
        fetchAsString: config.fetchAsString,
        fetchAsBuffer: config.fetchAsBuffer,
        externalAuth: config.externalAuth
      });

      this.isInitialized = true;
      console.log(`
🏝️  ORACLE AUTONOMOUS JSON DATABASE INITIALIZED
══════════════════════════════════════════════════════
📊 Pool Size: ${config.poolMin} - ${config.poolMax} connections
🔧 Connection Timeout: ${config.connectTimeout}s
🔐 Authentication: ${config.externalAuth ? 'External' : 'Password'}
📍 Host: ${config.connectionString.split('/')[0]}
══════════════════════════════════════════════════════
      `);

      return { success: true };

    } catch (error) {
      console.error('❌ Oracle database initialization failed:', error.message);

      if (this.connectionRetries < this.maxRetries) {
        this.connectionRetries++;
        console.log(`🔄 Retrying connection (${this.connectionRetries}/${this.maxRetries})...`);
        await new Promise(resolve => setTimeout(resolve, 2000));
        return this.initialize(initConfig);
      }

      throw new Error(`Failed to initialize Oracle database after ${this.maxRetries} attempts: ${error.message}`);
    }
  }

  // Get connection from pool
  async getConnection() {
    if (!this.isInitialized) {
      throw new Error('Database connection pool not initialized. Call initialize() first.');
    }

    try {
      const connection = await this.pool.getConnection();
      return connection;
    } catch (error) {
      console.error('❌ Failed to get database connection:', error.message);
      throw error;
    }
  }

  // Execute query with automatic cleanup
  async executeQuery(sql, bindParams = {}, options = {}) {
    let connection;

    try {
      connection = await this.getConnection();
      const result = await connection.execute(sql, bindParams, {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
        autoCommit: options.autoCommit || true,
        ...options
      });
      return result;
    } catch (error) {
      console.error('❌ Query execution failed:', error.message);
      throw error;
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (closeError) {
          console.error('⚠️ Error closing connection:', closeError.message);
        }
      }
    }
  }

  // Get pool statistics
  async getPoolStats() {
    if (!this.pool) {
      throw new Error('Connection pool not initialized');
    }

    return {
      connectionsInUse: this.pool.connectionsInUse,
      connectionsOpen: this.pool.connectionsOpen,
      poolMin: this.pool.poolMin,
      poolMax: this.pool.poolMax,
      poolIncrement: this.pool.poolIncrement,
      totalStatistic: this.pool._totalConnectionRequests,
      freeStatistic: this.pool._totalRequestsDequeued,
      pendingQueueSize: this.pool._connectionQueue.size
    };
  }

  // Health check
  async healthCheck() {
    try {
      const connection = await this.getConnection();
      await connection.ping();
      await connection.close();

      return {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        pool: await this.getPoolStats()
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        error: error.message,
        pool: await this.getPoolStats().catch(() => null)
      };
    }
  }

  // Graceful shutdown
  async closePool() {
    if (this.pool) {
      try {
        await this.pool.close(10); // Drain time in seconds
        console.log('🛑 Oracle connection pool closed successfully');
      } catch (error) {
        console.error('❌ Error closing connection pool:', error.message);
        throw error;
      }
    }
  }
}

//=============================================
// GLOBAL CONNECTION INSTANCE
//=============================================
const connectionManager = new OracleConnectionManager();

//=============================================
// MODULE EXPORTS
//=============================================
module.exports = {
  ORACLE_CONFIG,
  OracleConnectionManager,
  connectionManager,
  oracledb
};

//=============================================
// ENVIRONMENT VALIDATION
//=============================================
process.on('SIGTERM', async () => {
  console.log('🛑 Received SIGTERM, closing Oracle connection pool...');
  await connectionManager.closePool();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('🛑 Received SIGINT, closing Oracle connection pool...');
  await connectionManager.closePool();
  process.exit(0);
});

//=============================================
// DEVELOPMENT HELPERS
//=============================================
if (process.env.NODE_ENV === 'development') {
  console.log('🔧 Development mode: Oracle connection validation enabled');
}